<?php
return [
   "redis_port" => '6379',
   "redis_pass" => '',
   "redis_next" => '10',
   "redis_period" => '2',
   "redis_ips" => '1',
   "redis_msg" => '{"code":203,"msg":"\\u8bf7\\u6c42\\u592a\\u9891\\u7e41\\uff0c\\u8bf7\\u7a0d\\u540e\\u518d\\u8bd5\\uff01"}',
];
?>