<?php
return [
    'player' => __DIR__ . '/player.php',
];
