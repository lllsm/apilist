<?php
/*项目配置文件*/
return [
	'db' => 'mysql', 			//数据库类型
	'host' => '127.0.0.1', 		//服务器地址
	'port' => '3306', 			//端口
	'user' => 'apilist_cllsm_to', 			//用户名
	'pass' => 'cxDj3xAbLJfcMbe6', 			//密码
	'charset' => 'utf8', 		//字符集
	'dbname' => 'apilist_cllsm_to'		//默认数据库
];
