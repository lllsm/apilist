<?php
return [
   "title" => '追鸭追API',
   "name" => '提供免费接口调用平台',
   "keywords" => '追鸭追API,聚合数据,API数据接口,API,免费接口,免费api接口调用,免费API数据调用,零艺客API,零艺API',
   "description" => '追鸭追API是零艺免费提供API数据接口调用服务平台 - 我们致力于为用户提供稳定、快速的免费API数据接口服务。',
   "time" => '2019',
   "icp" => '<span>© 2017-2023</span><a href="http://apiv.aa1.cn/"                      target="_blank">粤ICP备2023001078号-1</a><span></span>',
   "about" => '<p>本API 平台是 基于<a href="#/" target="_blank">ZeroArt&XiaRou</a>支持并维护的 API 接口项目，致力于为用户提供稳定、快速的免费 API 接口服务平台。 </p>
                <p>
                    反馈或建议请发送邮件至：
                </p>',
   "target" => 'webinfo',
];
?>