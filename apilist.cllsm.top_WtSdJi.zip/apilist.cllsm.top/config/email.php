<?php
return [
   "mail_name" => '',
   "mail_smtp" => '',
   "mail_port" => '',
   "mail_user" => '',
   "mail_pwd" => '',
];
?>