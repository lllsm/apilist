<?php

/**
 *	Entry name：项目名称
 *	Description：项目说明
 *	Author：ZERO-ART
 *	Author Url：http://www.lykep.com
 * 	Contact：708298599  656001878
 *	2019-11-07 15:16:44
 */
function test()
{
    return "Hello world";
}
