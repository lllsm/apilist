<?php

/**
 * 静态文件路径 $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['SERVER_NAME']
 */
define('assets',   '/assets');

//后台登录认证
define("api_admin_auth", "api_admin_auth");

//用户登录认证
define("api_user_auth", "api_user_auth");
