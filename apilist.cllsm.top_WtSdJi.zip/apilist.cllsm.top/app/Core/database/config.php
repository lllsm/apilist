<?php
$config = require __DIR__ . '/../../../config/database.php'; //获取数据库信息
