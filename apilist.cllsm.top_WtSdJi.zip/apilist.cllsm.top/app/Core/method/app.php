<?php
//文件操作类
require __DIR__ . '/Storage.php';
//核心操作类
require __DIR__ . '/Controller.php';
//缓存处理类
require __DIR__ . '/Cache.php';
