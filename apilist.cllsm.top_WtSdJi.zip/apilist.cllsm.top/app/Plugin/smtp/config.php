<?php

/*邮件配置*/
$mailpz = require_once APP_CONFIG . "email.php";

// $mailpz = array(
// 	'mail_name' => '零艺客服助手', //发件人姓名
// 	'mail_smtp' => 'smtp.qq.com', //SMTP地址
// 	'mail_port' => 465, //SMTP端口
// 	'mail_user' => '952228124@qq.com', //邮箱账号
// 	'mail_pwd' => 'cgiiexolzaawbcfc' //邮箱密码（授权码）
// );
