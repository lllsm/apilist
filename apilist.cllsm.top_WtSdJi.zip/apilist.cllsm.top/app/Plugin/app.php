<?php
//中间层
// class Plugins
// {
//     //初始化
//     public function __construct()
//     {
//         // appinit();
//     }

//     public static function appinit()
//     {
//         require __DIR__ . '/360/Controller.php';
//     }
// }
require __DIR__ . '/smtp/functions.php';
