<?php
//后台数据库语句
require __DIR__ . '/admin.php';
//用户数据库语句
require __DIR__ . '/user.php';
