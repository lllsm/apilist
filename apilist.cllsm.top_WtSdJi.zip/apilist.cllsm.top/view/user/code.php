<?php
captcha(@$code);
