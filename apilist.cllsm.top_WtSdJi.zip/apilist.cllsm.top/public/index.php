<?php

/**
 *	Entry name：项目名称
 *	Description：起始文件
 *	Author：ZERO-ART
 *	Author Url：http://www.lykep.com
 * 	Contact：708298599  656001878
 *	2019-12-25 16:16:22
 */
// error_reporting(0);

// echo json_encode($_SERVER);
// echo $_SERVER['REQUEST_URI'];
// exit();
//初始化
require __DIR__ . '/../app/init.php';

// echo json_encode($_SERVER);
